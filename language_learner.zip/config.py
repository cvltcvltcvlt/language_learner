class Database:
    DATABASE_URL = "postgresql+asyncpg://postgres:postgres@localhost:54323"
